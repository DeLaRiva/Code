#include <string>
#include <limits>
#include <vector>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <fstream>
#include "grids.h"

using namespace std;

	grids::grids()
	{
		m_grid=0.; 
	}

	grids::~grids(){}	

	grids::grids(ifstream& input_grids)										// ifstream input to read from file
	{
		m_grid=0.; 
		while(!input_grids.eof()) 
		{			
			if(isdigit(input_grids.peek()))								// pointer searching in input stream for lines beginning with digits
			{
				break;										// if found, stop searching
			}		
			else input_grids.ignore(std::numeric_limits<std::streamsize>::max(), '\n');			// Ignore(since delimiter \n with a (max) number of characters)
		}
		input_grids >> m_grid;	// >> reads line from the input stream/from where the pointer is pointing to
	}

	void grids::write(ostream& out) const
	{
		out << endl;
		out << "grid \t" <<endl;
		out << m_grid;
		out << endl;
	}

	ostream& operator<<(ostream& out, const grids& grids)
	{     
		grids.write(out);
		return out;
	}

	int grids::getgrid() const 
	{
		return m_grid;
	}
	void grids::setgrid(int a_grid)
	{
		m_grid=a_grid;
	}
