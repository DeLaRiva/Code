#include <vector>
#include <string>
#include "TCanvas.h"
#include <TGraphErrors.h>
#include <TStyle.h>
#include <TF1.h>
#include <TH1.h>
#include <TROOT.h> 
#include <TFile.h>
#include <TH1F.h>
#include <TLine.h>
#include "Fit.h"

using namespace std;

	FIT::FIT(){}
	FIT::~FIT(){}	
/*
	FIT::FIT(vector<double> M_vec_raw, vector<double> Ubias_vec_raw, vector<double> M_vec_fit, vector<double> Ubias_vec_fit, double Ubr)
	{

	}
*/
	FIT::FIT(vector<double>& M_vec_raw, vector<double>& Ubias_vec_raw, vector<double>& M_vec_fit, vector<double>& Ubias_vec_fit, double& Ubr, long int& SN, TFile* Outputfile, double& fit_point) 
	{

	m_fitted_raw_dM=0;
	m_fitted_fit_dM=0;
	m_corresponding_Ubias_raw=0;
	m_corresponding_Ubias_fit=0;
	m_deviation_fits=0;
	//cout << endl << "Fit APD data points" << endl;

	char name[100];
	int SN_name=(int)SN;
	sprintf(name,"APD fit SN: %02d",SN_name);
	TCanvas* c=new TCanvas(name, name, 1500, 1000);
	c->Divide(2,2);

	c->cd(1);

	vector<double> dx_raw_vec, dy_raw_vec;
	//const int N=(int)M_vec_raw.size();
	//double dx_raw[N], dy_raw[N];

	for(unsigned long int i=0;i<M_vec_raw.size();i++)
	{
		dx_raw_vec.push_back(0.2);
		dy_raw_vec.push_back((double)M_vec_raw[i]*0.02);
		//cout << "SN: " << m_SN << "   dx_raw: " << dx_raw_vec[i] << "   dy_raw: " << dy_raw_vec[i] << " M_vec_raw: " << M_vec_raw[i] << endl;
		//dx_raw[i]=dx_raw_vec[i];
		//dy_raw[i]=dy_raw_vec[i];
	}	


	// Only data points besides to M=fit_point:
	double certain_data_points_M[4];
	double certain_data_points_Ubias[4];
	//double dy_raw_adjust[4];

	for(int i=0;i<2;i++)
	{
		for(unsigned long int j=0;j<M_vec_raw.size();j++)
		{
			if(M_vec_raw[j]<fit_point)
			{

				certain_data_points_M[0]=M_vec_raw[j];		
				certain_data_points_Ubias[0]=Ubias_vec_raw[j];
				//dy_raw_adjust[0]=dy_raw[j];
			}
			//cout << "M_raw: " << M_raw[j] << endl;		
		}

		for(unsigned long int j=0;j<M_vec_raw.size();j++)
		{
			if(M_vec_raw[j]<fit_point && M_vec_raw[j]<certain_data_points_M[0])
			{
				certain_data_points_M[1]=M_vec_raw[j];		

				certain_data_points_Ubias[1]=Ubias_vec_raw[j];
				//dy_raw_adjust[1]=dy_raw[j];
			}
			//cout << "M_raw: " << M_raw[j] << endl;		
		}
	}
	certain_data_points_M[2]=1000;
	for(int i=2;i<4;i++)
	{
		for(unsigned long int j=0;j<M_vec_raw.size();j++)
		{
			if(M_vec_raw[j]>fit_point && M_vec_raw[j]<certain_data_points_M[2]) 
			{
				certain_data_points_M[2]=M_vec_raw[j];		
				certain_data_points_Ubias[2]=Ubias_vec_raw[j];
				//dy_raw_adjust[2]=dy_raw[j];
			}
		}
		for(unsigned long int j=0;j<M_vec_raw.size();j++)

		{
			if(M_vec_raw[j]>fit_point && M_vec_raw[j]>certain_data_points_M[2]) 
			{
				certain_data_points_M[3]=M_vec_raw[j];		
				certain_data_points_Ubias[3]=Ubias_vec_raw[j];
				//dy_raw_adjust[3]=dy_raw[j];
				break;
			}
		}
	}

	/* for(int i=0;i<4;i++)
	{
		//cout << "dy: " << dy_fit[i] << "   dy_adjust: " << dy_fit_adjust[i] << endl;
		cout << "Raw: certain data points Ubias: " << certain_data_points_Ubias[i] << "   |   " << "certain data points M: " << certain_data_points_M[i] << endl;
	} */

	// raw data-fit:
	TGraphErrors* raw_err = new TGraphErrors(4, certain_data_points_Ubias, certain_data_points_M);
	//TGraphErrors* raw_erre = new TGraphErrors(4, certain_data_points_Ubias, certain_data_points_M, dx_raw, dy_raw_adjust);

	//TF1* fit_raw = new TF1("Raw data fit", "[2]/(1.0-(x/[0])**[1])+(1-[2])",300.0,Ubr-1.0);
	TF1* fit_raw = new TF1("Raw data fit", "pol2",certain_data_points_Ubias[1],certain_data_points_Ubias[3]);
	fit_raw->SetParameter(0, 380.0);
	fit_raw->SetParameter(1, 1.2);
	fit_raw->SetParameter(2, 1.0);
	fit_raw->SetParameter(3, 0.03);
	fit_raw->SetParLimits(3, 1e-9, 10.0 );
	//fit_raw->SetParameter(4, 1);
	fit_raw->SetLineColor(kRed);	

	raw_err->SetMarkerStyle(22);	
	raw_err->SetMarkerColor(kBlue-2);		
	raw_err->SetMarkerSize(2);		
	raw_err->GetXaxis()->SetTitle("U_{bias}");
	raw_err->GetYaxis()->SetTitle("M");
	raw_err->SetTitle("APD gain fit");
	raw_err->GetXaxis()->SetRangeUser(certain_data_points_Ubias[1]-1.0, 360);
	raw_err->GetYaxis()->SetRangeUser(90, 210);

	raw_err->Fit(fit_raw, "Q");
	//raw_erre->Fit(fit_raw, "Q");

	double a_Ubias=0;
	a_Ubias=fit_raw->GetX(fit_point);
	//cout << "a_Ubias: " << a_Ubias << endl;

	TLine *l_x = new TLine(certain_data_points_Ubias[1]-0.9,fit_point,a_Ubias,fit_point);
	l_x->SetLineWidth(2);
	l_x->SetLineColor(kGreen+1);
	l_x->SetLineStyle(8);

	TLine *l_y = new TLine(a_Ubias,90,a_Ubias,fit_point);
	l_y->SetLineWidth(2);
	l_y->SetLineColor(kGreen+1);
	l_y->SetLineStyle(8);

	double a_dUbias=0;
	a_dUbias=fit_raw->Derivative(a_Ubias);
	a_dUbias=a_dUbias/fit_point;
	a_dUbias=a_dUbias*100.0;

	raw_err->Draw("A*");
	l_x->Draw();
	l_y->Draw();

	c->Update();
	c->cd(3);

	TGraph *derived_graph = new TGraph(fit_raw,"d"); // That's the "Derivative" part of "DrawDerivative"
	for(int i = 0, n = derived_graph->GetN(); i < n; ++i)
	{
		derived_graph->GetY()[i] *= 100;
		derived_graph->GetY()[i] /= fit_point;
	}
	derived_graph->GetXaxis()->SetRangeUser(certain_data_points_Ubias[1]-1.0, 360);
	derived_graph->GetYaxis()->SetRangeUser(4, 10);
	derived_graph->GetXaxis()->SetTitle("U_{bias}");
	derived_graph->GetYaxis()->SetTitle("dM");
	derived_graph->SetTitle("APD differential gain fit");
	derived_graph->Draw("al"); 

	int number=70;
	double derived_points[number];
	double x[number];
	for(int i=0;i<number;i++)
	{
		x[i]=300+(370-300)*i/number;
		derived_points[i]=fit_raw->Derivative(x[i])/fit_point*100;
		//cout << "x: " << x[i] << endl;
	}

	TLine *l_xx = new TLine(certain_data_points_Ubias[1]-1.6,a_dUbias,a_Ubias,a_dUbias);
	l_xx->SetLineWidth(2);
	l_xx->SetLineColor(kGreen+1);
	l_xx->SetLineStyle(8);

	l_xx->Draw("A");

	TLine *l_yy = new TLine(a_Ubias,4,a_Ubias,a_dUbias);
	l_yy->SetLineWidth(2);
	l_yy->SetLineColor(kGreen+1);
	l_yy->SetLineStyle(8);


	l_yy->Draw("SAME");

	c->Update();
	c->cd(2);

	// Fit of Andreas fit data points

	vector<double> dx_fit_vec, dy_fit_vec;
	//double dy_fit[N];
	for(unsigned long int i=0;i<M_vec_fit.size();i++)
	{
		dx_fit_vec.push_back(0.2);
		dy_fit_vec.push_back((double)M_vec_fit[i]*0.02);
		//dy_fit[i]=dy_fit_vec[i];
		//cout << "SN: " << m_SN << "   dx_fit: " << dx_fit_vec[i] << "   dy_fit: " << dy_fit_vec[i] << " M_vec_fit: " << M_vec_fit[i] << endl;
	}

	//double dy_fit_adjust[4];
	// Only data points besides to M=fit_point:
	for(int i=0;i<4;i++)
	{
		certain_data_points_M[i]=0;
		certain_data_points_Ubias[i]=0;
		//dy_fit_adjust[i]=0;
	}

	for(int i=0;i<2;i++)
	{
		for(unsigned long int j=0;j<M_vec_fit.size();j++)
		{
			if(M_vec_fit[j]<fit_point)
			{
				certain_data_points_M[0]=M_vec_fit[j];		
				certain_data_points_Ubias[0]=Ubias_vec_fit[j];
				//dy_fit_adjust[0]=dy_fit[j];
			}
			//cout << "M_raw: " << M_raw[j] << endl;		
		}
		for(unsigned long int j=0;j<M_vec_fit.size();j++)
		{
			if(M_vec_fit[j]<fit_point && M_vec_fit[j]<certain_data_points_M[0])
			{
				certain_data_points_M[1]=M_vec_fit[j];		
				certain_data_points_Ubias[1]=Ubias_vec_fit[j];
				//dy_fit_adjust[1]=dy_fit[j];
			}
			//cout << "M_raw: " << M_raw[j] << endl;		
		}
	}
	certain_data_points_M[2]=1000;
	for(int i=2;i<4;i++)
	{
		for(unsigned long int j=0;j<M_vec_fit.size();j++)
		{
			if(M_vec_fit[j]>fit_point && M_vec_fit[j]<certain_data_points_M[2]) 
			{
				certain_data_points_M[2]=M_vec_fit[j];		
				certain_data_points_Ubias[2]=Ubias_vec_fit[j];
				//dy_fit_adjust[2]=dy_fit[j];
			}
		}
		for(unsigned long int j=0;j<M_vec_fit.size();j++)
		{
			if(M_vec_fit[j]>fit_point && M_vec_fit[j]>certain_data_points_M[2]) 
			{
				certain_data_points_M[3]=M_vec_fit[j];		
				certain_data_points_Ubias[3]=Ubias_vec_fit[j];
				//dy_fit_adjust[3]=dy_fit[j];
				break;
			}
		}
	}

	TGraph* fit_andrea = new TGraph(4, certain_data_points_Ubias, certain_data_points_M);

	TF1 *fit_andrea_fit = new TF1("fit of andrea''s fit","(1/(1-((x)/[0])**[1])+[2])", 300.0,Ubr-1.0); 

	fit_andrea_fit->SetParameter(0,410);
	fit_andrea_fit->SetParameter(1,0.3);
	fit_andrea_fit->SetParameter(2,10.);
	fit_andrea_fit->SetLineColor(kBlue-1);
	// fit_andrea_fit->SetLineStyle(3);
	fit_andrea->Fit(fit_andrea_fit, "Q");

	fit_andrea->SetMarkerStyle(22);	

	fit_andrea->SetMarkerColor(kBlue-2);		
	fit_andrea->SetMarkerSize(2);		
	fit_andrea->GetXaxis()->SetTitle("U_{bias}");
	fit_andrea->GetYaxis()->SetTitle("M");
	fit_andrea->SetTitle("APD gain fit Andrea");
	fit_andrea->GetXaxis()->SetRangeUser(certain_data_points_Ubias[1]-1.0, 370);
	fit_andrea->GetYaxis()->SetRangeUser(90, 210);

	double a_Ubias_fit=0;
	a_Ubias_fit=fit_andrea_fit->GetX(fit_point);


	TLine *l_xxx = new TLine(certain_data_points_Ubias[1]-0.5,fit_point,a_Ubias_fit,fit_point);
	l_xxx->SetLineWidth(2);
	l_xxx->SetLineColor(kGreen+1);
	l_xxx->SetLineStyle(8);

	TLine *l_yyy = new TLine(a_Ubias_fit,90,a_Ubias_fit,fit_point);
	l_yyy->SetLineWidth(2);
	l_yyy->SetLineColor(kGreen+1);
	l_yyy->SetLineStyle(8);

	fit_andrea->Fit(fit_andrea_fit, "Q");
	fit_andrea->Draw("A*");
	//fit_andrea_err->Draw("A*");
	l_xxx->Draw("SAME");
	l_yyy->Draw("SAME");

	double a_dUbias_fit=0;
	a_dUbias_fit=fit_andrea_fit->Derivative(a_Ubias_fit);
	a_dUbias_fit=a_dUbias_fit/fit_point;
	a_dUbias_fit=a_dUbias_fit*100.0;

	c->Update();
	c->cd(4);


	double derived_points_andrea[number];
	for(int i=0;i<number;i++)
	{
		derived_points_andrea[i]=fit_andrea_fit->Derivative(x[i])/fit_point*100;
	}

	double difference_fits[number];
	for(int i=0;i<number;i++)
	{
		difference_fits[i]=derived_points[i]-derived_points_andrea[i];
	}
	float voltage[number];
	std::string voltage_string[number];
	for(int i=0;i<number;i++)
	{
		voltage[i]=(float)x[i];
		voltage_string[i]=std::to_string(voltage[i]);
		//cout << "voltage: " << voltage[i] << "   " << "x: " << x[i] << endl;
	}

	sprintf(name,"Difference: %02d",SN_name);
	TH1F* difference_graph = new TH1F("Difference between both fits","Difference between both fits",number,300,370);
	if(number<=100)
	{
		for(int i=1;i<number;i++)
		{
			difference_graph->SetBinContent(i, difference_fits[i-1]);
			difference_graph->GetXaxis()->SetBinLabel(i,voltage_string[i-1].c_str());
		}
	}
	else
	{
		for(int i=1;i<number;i++)
		{
			difference_graph->GetXaxis()->SetBinLabel(i,voltage_string[i-1].c_str());
			i+=5;
		}
	}
   	difference_graph->SetFillColor(4);
   	difference_graph->SetBarWidth(0.8);
   	difference_graph->SetBarOffset(0.1);
   	difference_graph->SetStats(0);
   	//difference_graph->SetMinimum(0.0);
   	//difference_graph->SetMaximum(6);
	difference_graph->GetXaxis()->SetTitle("U_{bias}");
	difference_graph->GetYaxis()->SetTitle("#Delta [ #frac{#frac{1}{M} #frac{dM}{dV}}{U_{bias}} ]");
	difference_graph->SetAxisRange(350,360,"X");
	difference_graph->GetXaxis()->SetTitleOffset(1.3);
	difference_graph->GetYaxis()->SetTitleOffset(1.7);
	difference_graph->SetMinimum(-0.25);
	difference_graph->SetMaximum(0.25);
	difference_graph->SetTitle("#Delta dM between both derivatives");
	difference_graph->Draw("B");

	c->Update();
	c->Write(name);
	if(Outputfile!=0)
	{
		Outputfile->Write(); 	
	}

	/* for(int i=0;i<4;i++)
	{
		cout << "Fit: certain data points Ubias: " << certain_data_points_Ubias[i] << "   |   " << "certain data points M: " << certain_data_points_M[i] << endl;
	} */
	//cout << "Fit succesfully done with following Ubias value: " << a_Ubias << endl;

	//cout << "Fitted raw values: " << a_Ubias << "| Fitted fit values: " << a_Ubias_fit <<endl;
	//cout << "Fitted raw values: " << a_dUbias << "| Fitted fit values: " << a_dUbias_fit <<endl;
	double deviation_fits=a_dUbias-a_dUbias_fit;


	m_fitted_raw_dM=a_dUbias;
	m_fitted_fit_dM=a_dUbias_fit;
	m_corresponding_Ubias_raw=a_Ubias;
	m_corresponding_Ubias_fit=a_Ubias_fit;
	m_deviation_fits=deviation_fits;
	

	delete raw_err;
	delete fit_raw;
	delete fit_andrea;
	delete fit_andrea_fit;
	delete l_x;
	delete l_y;
	delete l_xx;
	delete l_yy;
	delete l_xxx;
	delete l_yyy;
	//delete derived_graph;
	delete c;
	delete difference_graph;
	//return 0;

	}

	double FIT::get_fitted_dM_raw() const
	{
		return m_fitted_raw_dM;
	}

	void FIT::set_fitted_dM_raw(double a_fitted_raw_dM)
	{
		m_fitted_raw_dM = a_fitted_raw_dM;
	}

	double FIT::get_fitted_dM_fit() const
	{
		return m_fitted_fit_dM;
	}

	void FIT::set_fitted_dM_fit(double a_fitted_fit_dM)
	{
		m_fitted_fit_dM = a_fitted_fit_dM;
	}

	double FIT::get_corresponding_Ubias_raw() const
	{
		return m_corresponding_Ubias_raw;
	}

	void FIT::set_corresponding_Ubias_raw(double a_corresponding_Ubias_raw)
	{
		m_corresponding_Ubias_raw = a_corresponding_Ubias_raw;
	}

	double FIT::get_corresponding_Ubias_fit() const
	{
		return m_corresponding_Ubias_fit;
	}

	void FIT::set_corresponding_Ubias_fit(double a_corresponding_Ubias_fit)
	{
		m_corresponding_Ubias_fit = a_corresponding_Ubias_fit;
	}

	double FIT::get_deviation_fits() const
	{
		return m_deviation_fits;
	}

	void FIT::set_deviation_fits(double a_deviation_fits)
	{
		m_deviation_fits = a_deviation_fits;
	}

