#ifndef FIT_H
#define FIT_H

using namespace std;

class TFile;

class FIT
{
	public:
		FIT();
		FIT(vector<double>& M_vec_raw, vector<double>& Ubias_vec_raw, vector<double>& M_vec_fit, vector<double>& Ubias_vec_fit, double& Ubr, long int& SN, TFile* Outputfile, double& fit_point);
		~FIT();

		// void fit(const vector<double> &M_vec_raw, const vector<double> &Ubias_vec_raw, const vector<double> &M_vec_fit, const vector<double> &Ubias_vec_fit, double &Ubr, double &SN);
		void fit();

		double get_fitted_dM_raw() const;
		void set_fitted_dM_raw(double a_fitted_raw_dM);
		double get_fitted_dM_fit() const;
		void set_fitted_dM_fit(double a_fitted_fit_dM);

		double get_corresponding_Ubias_raw() const;
		void set_corresponding_Ubias_raw(double a_corresponding_Ubias_raw);
		double get_corresponding_Ubias_fit() const;
		void set_corresponding_Ubias_fit(double a_corresponding_Ubias_fit);
		double get_deviation_fits() const;
		void set_deviation_fits(double a_deviation_fits);

	private:	
		double m_fitted_raw_dM;
		double m_fitted_fit_dM;
		double m_corresponding_Ubias_raw;
		double m_corresponding_Ubias_fit;
		double m_deviation_fits;
		double SN;

		vector<double> M_vec_raw;
		vector<double> Ubias_vec_raw;
		vector<double> M_vec_fit;
		vector<double> Ubias_vec_fit;
};

#endif
