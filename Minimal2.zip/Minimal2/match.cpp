/**** corrupted unsorted chunks ****/
/** in the complete project it is a memory corruption **/

#include <fstream>
#include <iostream>
#include <string>
#include <limits>
#include <vector>
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>

// ROOT
#include <TFile.h>
#include "APD.h"
#include "Fit.h"
#include "grids.h"

using namespace std;
//using namespace R;   

class APD_ignore
{
	public: 
		APD_ignore() {m_SN=0.;}
		APD_ignore(ifstream& input_ignore)
		{
			m_SN=0.; 
			while(!input_ignore.eof()) 
			{			
				if(isdigit(input_ignore.peek()))								
				{
					break;									
				}	
				else input_ignore.ignore(std::numeric_limits<std::streamsize>::max(), '\n');		
			}	
			input_ignore >> m_SN; 
		}
		~APD_ignore(){}

		int getSN() const { return m_SN; }
		void setSN(int a_SN) { m_SN=a_SN; }

		private:
		int m_SN;
};


vector<APD> database(const char *INPUTFILE, bool EXTRACT_APD_VALUE, double& fit_point)
{
	cout<<endl;

	/**********************************************************************/ 
	/***************************** Data input *****************************/ 
	/**********************************************************************/ 

	ifstream input_database(INPUTFILE);
	if(!input_database)											
	{
		cerr << "File \"" << INPUTFILE << "\" not found\n \a" << endl; 
		exit(-1);
	}
	else cout << endl << ">> Read in APDs: Open \"" << INPUTFILE << "\" as input" << endl;
	vector<APD> apdvec_database;									

	for(int i=0; !input_database.eof();i++)
	{
		APD apd(input_database);										
		apdvec_database.push_back(apd);				
	}

	if(apdvec_database.size()==0)
	{
		cout << "\t Reading from \"" << INPUTFILE << "\" failed. No parameters found. \a" << endl; 
		exit(-1);
	}

	for(vector<APD>::iterator it = apdvec_database.begin(); it!=apdvec_database.end(); )
	{		
		if(it->getSN()==0)
		{
			it=apdvec_database.erase(it);
			if(it!=apdvec_database.end())		
			cout << "\t SN: " << it->getSN() << endl;
		} 
		else 
		{
			it++;
		}
	}
	if(apdvec_database.size()%2==0);
	else
	{
		vector<APD>::iterator it = apdvec_database.end();
		it=apdvec_database.erase(it);
	}

	cout << " \t > Fit reading in APDs " << endl;	
	TFile *Outputfile=new TFile("Fitted.root", "RECREATE"); 
	// Fit APD:
	int number=0;
	if(EXTRACT_APD_VALUE)
	{
		for(size_t i = 0; i<apdvec_database.size(); i++)
		{	
			if(number % 75 == 0 && number!=0) cout <<"\t \t " << number << " APDs read and fitted " <<endl;
			apdvec_database[i].fit_APD(Outputfile, fit_point);
			// cout << endl << "\t Current APD: " << i << endl;
			// cout << endl << "\t Current APD: " << i << "   \t SN: " << apdvec_database[i].getSN() << endl;
			// cout << "Fitted dM raw: " << apdvec_database[i].get_fitted_dM_raw() << "   Fitted dM fit: " << apdvec_database[i].get_fitted_dM_fit() << endl;	
/*			if(apdvec_database[i].get_deviation_fits()>0.5)
			{	
				cout << "\t SN: " << apdvec_database[i].getSN() << "   #Beware: Huge fit gap!" << endl;
				cout << "\t Fitted corresponding Ubias raw: " << apdvec_database[i].get_corresponding_Ubias_raw() << endl;	
				cout << "\t Fitted corresponding Ubias fit: " << apdvec_database[i].get_corresponding_Ubias_fit() << endl;				
				cout << "\t Deviation fits: " << apdvec_database[i].get_deviation_fits() << endl;	
			} */
		}
	}

/*
	//Fit data:
	for(unsigned long int i=0; i<apdvec_database.size(); i++)
	{
		fit(apdvec_database[i].getM_vec_raw(), apdvec_database[i].getUbias_vec_raw(), apdvec_database[i].getM_vec_fit(), apdvec_database[i].getUbias_vec_fit(), apdvec_database[i].getUbr(), apdvec_database[i].getdM_vec_raw(), apdvec_database[i].getdM_vec_fit(), Plot, i);
	}
*/
	Outputfile->Write();
	Outputfile->Close();

	cout <<"\t\t " << apdvec_database.size() << " APDs read out" << endl;
	return apdvec_database;	
}




vector<APD> database_irradiated(const char *INPUTFILE_IRRADIATED, bool EXTRACT_APD_VALUE, vector<APD> &apdvec_database, double& fit_point)
{
	cout<<endl;

	/**********************************************************************/ 
	/************************ Data input irradiated ***********************/ 
	/**********************************************************************/ 

	ifstream input_database(INPUTFILE_IRRADIATED);
	if(!input_database)											
	{
		cerr << "File \"" << INPUTFILE_IRRADIATED << "\" not found\n \a" << endl; 
		exit(-1);
	}
	else cout << ">> Check irradiation alterations: Open \"" << INPUTFILE_IRRADIATED << "\" as input" << endl;
	vector<APD> apdvec_database_irradiated;		

	for(int i=0; !input_database.eof();i++)
	{
		APD apd(input_database);										
		apdvec_database_irradiated.push_back(apd);		
		// cout << endl << "\t Current APD: " << i << endl;
	}

	if(apdvec_database_irradiated.size()==0)
	{
		cout << "\t Reading from \"" << INPUTFILE_IRRADIATED << "\" failed. No parameters found. \a" << endl; 
		exit(-1);
	}

	for(vector<APD>::iterator it = apdvec_database_irradiated.begin(); it!=apdvec_database_irradiated.end(); )
	{		
		if(it->getSN()==0)
		{
			it=apdvec_database_irradiated.erase(it);
			if(it!=apdvec_database_irradiated.end())
			{
				cout << "\t SN: " << it->getSN() << endl;
			}
		} 
		else 
		{
			it++;
		}
	}
	cout <<"\t > "<< apdvec_database_irradiated.size() << " irradiated APDs read out" << endl;

	cout << "\t > Searching for APDs in both databases" << endl;
	int amount_apds=0;
	for(size_t i = 0; i<apdvec_database.size(); i++)	
	{
		for(size_t j = 0; j<apdvec_database_irradiated.size(); j++)
		{
			long int SN_i = apdvec_database[i].getSN();
			long int SN_j = apdvec_database_irradiated[j].getSN();
			if(SN_i==SN_j && apdvec_database_irradiated[j].getIrradiatedState()!=APD::IRRADIATED)
			{
				apdvec_database_irradiated[j].setIrradiatedState(APD::IRRADIATED);
				amount_apds+=1;
			}
		}
	}
	cout <<"\t\t "<< amount_apds << " APDs found with before<>after-irradiation parameters" << endl;

	for(vector<APD>::iterator it = apdvec_database_irradiated.begin(); it!=apdvec_database_irradiated.end(); )
	{		
		if(it->getIrradiatedState()==APD::UNKNOWN || it->getIrradiatedState()==APD::NOT_IRRADIATED)
		{
			it=apdvec_database_irradiated.erase(it);
			if(it!=apdvec_database_irradiated.end())
			{
				// cout << "\t SN: " << it->getSN() << endl;
			}
		} 
		else 
		{
			it++;
		}
	}

	cout << "\t > Fit reading in of " << apdvec_database_irradiated.size() << " irradiated APDs " << endl;	
	TFile *Outputfile_irradiated=new TFile("Fitted_irradiated.root", "RECREATE"); 
	// Fit APD:
	int number=0;
	if(EXTRACT_APD_VALUE)
	{
		if(number % 75 == 0 && number!=0) cout <<"\t \t " << number << " APDs read and fitted " <<endl;
		for(size_t i = 0; i<apdvec_database_irradiated.size(); i++)
		{	
			apdvec_database_irradiated[i].fit_APD(Outputfile_irradiated, fit_point);
			// cout << endl << "\t Current APD: " << i << endl;
			// cout << endl << "\t Current APD: " << i << "   \t SN: " << apdvec_database[i].getSN() << endl;
			// cout << "Fitted dM raw: " << apdvec_database[i].get_fitted_dM_raw() << "   Fitted dM fit: " << apdvec_database[i].get_fitted_dM_fit() << endl;	
	/*		if(apdvec_database_irradiated[i].get_deviation_fits()>0.5)
			{	
				cout << "\t\t SN: " << apdvec_database_irradiated[i].getSN() << "   #Beware: Huge fit gap!" << endl;
				cout << "\t\t Fitted corresponding Ubias raw: " << apdvec_database_irradiated[i].get_corresponding_Ubias_raw() << endl;	
				cout << "\t\t Fitted corresponding Ubias fit: " << apdvec_database_irradiated[i].get_corresponding_Ubias_fit() << endl;				
				cout << "\t\t Deviation fits: " << apdvec_database_irradiated[i].get_deviation_fits() << endl << endl;	
			} */
		}
	}

	// Correlate ADPs relative to irradiation
	cout << "\t > Obtaining irradiation alteration parameters" << endl;
	amount_apds=0;
	for(size_t i=0; i<apdvec_database.size(); i++)	
	{
		double dM_irradiation_change=0;
		double Ubias_irradiation_change=0;
		for(size_t j=0; j<apdvec_database_irradiated.size(); j++)
		{
			long int SN_i = apdvec_database[i].getSN();
			long int SN_j = apdvec_database_irradiated[j].getSN();
			if(SN_i==SN_j)
			{
				amount_apds+=1;
				bool compared_radiation=false;
				if(EXTRACT_APD_VALUE)
				{
					// Change of fitted parameters due to irradiation:
					dM_irradiation_change=(apdvec_database[i].get_fitted_dM_raw()-apdvec_database_irradiated[j].get_fitted_dM_raw());					
					Ubias_irradiation_change=(apdvec_database[i].get_corresponding_Ubias_raw()-apdvec_database_irradiated[j].get_corresponding_Ubias_raw());			
					compared_radiation=true;
				}	
				else
				{
					// Change of parameters due to irradiation:
					dM_irradiation_change=(apdvec_database[i].getM_dM()-apdvec_database_irradiated[j].getM_dM());					
					Ubias_irradiation_change=(apdvec_database[i].getUbias()-apdvec_database_irradiated[j].getUbias());	
					compared_radiation=true;
				}
				if(compared_radiation==true)
				{
					apdvec_database[i].set_irradiation_change_dM(dM_irradiation_change);	
					apdvec_database[i].set_irradiation_change_Ubias(Ubias_irradiation_change);
				}
				else cout << "\t Obtaining irradiation alteration failed for APD: " << SN_i << endl;
			} 
		}
	}

	cout <<"\t\t "<< amount_apds << " APDs compared due to irradiation" << endl;

	Outputfile_irradiated->Write();
	Outputfile_irradiated->Close();

	return apdvec_database_irradiated;	
}



// Eliminate APDs which have already been matched
vector<APD_ignore> apds_ignore(const char* INPUTFILE_IGNORE)
{	
	ifstream input_ignore(INPUTFILE_IGNORE);
	if(!input_ignore)											
	{
		cerr << "File \"" << INPUTFILE_IGNORE << "\" not found\n \a" << endl; 
		exit(-1);
	}
	else cout << "Open \"" << INPUTFILE_IGNORE << "\" as input" << endl;

	vector<APD_ignore> apdvec_ignore;					
	for(int i=0; !input_ignore.eof();i++)
	{
		APD_ignore apd(input_ignore);											
		apdvec_ignore.push_back(apd);		
	}

	if(apdvec_ignore.size()==0)
	{
		cout << "Reading from \"" << INPUTFILE_IGNORE << "\" failed. No parameters found. \a" << endl; 
		exit(-1);
	}

	for (vector<APD_ignore>::iterator it = apdvec_ignore.begin(); it!=apdvec_ignore.end();)
	{
		if(it->getSN()==0)
		{
			it=apdvec_ignore.erase(it);		
		} 
		else 
		{
			it++;
		}
	}
	cout << apdvec_ignore.size() << " APDs to be considered as already matched" << endl;
	return apdvec_ignore;	
}

// Select only chosen grids
vector<grids> grids_available(const char* INPUTFILE_GRIDS)
{
	ifstream input_grids(INPUTFILE_GRIDS);
	ofstream out("grids.txt");
	if(!input_grids)												
	{
		cerr << "File \"" << INPUTFILE_GRIDS << "\" not found\n \a" << endl; 
		exit(-1);
	}
	else cout << "Open \"" << INPUTFILE_GRIDS << "\" as input" << endl;

	vector<grids> gridvec;											
	
	for(int i=0; !input_grids.eof();i++)
	{
		grids grids(input_grids);									
		gridvec.push_back(grids);		
	}

	if(gridvec.size()==0)
	{
		cout << "Reading from \"" << INPUTFILE_GRIDS << "\" failed. No parameters found. \a" << endl; 
		exit(-1);
	}

	for (vector<grids>::iterator it = gridvec.begin(); it!=gridvec.end();)
	{
		if(it->getgrid()==0)
		{
			it=gridvec.erase(it);		
		} 
		else 
		{
			it++;
		}
	} 
	cout << gridvec.size() << " grids read out" << endl;
	
	return gridvec;	
}



constexpr inline size_t binom(size_t n, size_t k) noexcept
{
	return
	(k>n) ? 0:						// out of range
	(k==0 || k==n) ? 1:					// edge
	(k==1 || k==n-1) ? n:					// first
	(k+k < n) ?						// recursive:
	(binom(n-1,k-1)*n)/k:					// path to k=1   is faster
	(binom(n-1,k)*n)/(n-k);					// path to k=n-1 is faster
}


//--- Matching
void match(vector<APD> apdvec_database, const char* OUTPUTFILE, bool EXTRACT_APD_VALUE)
{
	ofstream output(OUTPUTFILE);
	//ofstream output_simple(SIMPLE_OUTPUTFILE);

	cout<<endl<<">> Matching operation starts.. \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t abandon all hope, ye who enter here " << endl;
	cout<<"\t > Calculating edges .. will take a while.." << endl;

	// Define matching criteria
	double match_limit_dM, match_limit_Ubias, match_limit_irradiation_change_dM, match_limit_irradiation_change_Ubias;
	match_limit_dM=0.2;
	match_limit_Ubias=0.2;
	match_limit_irradiation_change_dM=0.2;
	match_limit_irradiation_change_Ubias=0.2;

	double leg_dM, leg_Ubias, leg_irradiation_change_dM, leg_irradiation_change_Ubias;								
	leg_dM=0.0;
	leg_Ubias=0.0;
	leg_irradiation_change_dM=0.0;
	leg_irradiation_change_Ubias=0.0;
	const int N = apdvec_database.size();
	// const int N = 3;
	vector<double> lx(N);
	vector<vector<double> > cost (N, vector<double>(N,0));
	vector<vector<double> > cost_binary (N, vector<double>(N,0));
	//cout << "\t Size of cost matrix: " << cost.size() << endl;
	// int sphere_amount=0;
	for(size_t i = 0; i<apdvec_database.size(); i++)
	{	
		// Define matching parameters
		double sphere=0.0;
		double dM_i, dM_j, Ubias_i, Ubias_j, SN_i, SN_j, irradiation_change_dM_i, irradiation_change_dM_j, irradiation_change_Ubias_i, irradiation_change_Ubias_j;
		for(size_t j = 0; j<apdvec_database.size(); j++)
		{	
			if(EXTRACT_APD_VALUE)
			{	// Parameter 1: dM
				dM_i = apdvec_database[i].get_fitted_dM_fit();
				dM_j = apdvec_database[j].get_fitted_dM_fit();
				// Parameter 2: Ubias
				Ubias_i = apdvec_database[i].get_corresponding_Ubias_fit();
				Ubias_j = apdvec_database[j].get_corresponding_Ubias_fit();
			}
			else
			{	// Parameter 1: dM
				dM_i = apdvec_database[i].get_fitted_dM_raw();
				dM_j = apdvec_database[j].get_fitted_dM_raw();
				// Parameter 2: Ubias
				Ubias_i = apdvec_database[i].get_corresponding_Ubias_raw();
				Ubias_j = apdvec_database[j].get_corresponding_Ubias_raw();
			}

			// Parameter 3: Ubias after irradiation
			irradiation_change_Ubias_i=apdvec_database[i].get_irradiation_change_Ubias();
			irradiation_change_Ubias_j=apdvec_database[j].get_irradiation_change_Ubias();
			// Parameter 4: dM after irradiation
			irradiation_change_dM_i=apdvec_database[i].get_irradiation_change_dM();
			irradiation_change_dM_j=apdvec_database[j].get_irradiation_change_dM();
			// Call SNs:
			SN_i = apdvec_database[i].getSN();
			SN_j = apdvec_database[j].getSN();
			if(SN_i!=SN_j && SN_i!=0 && SN_j!=0)
			{
				//double INF=100000000;
				leg_dM=(fabs(dM_i-dM_j))/(match_limit_dM);
				leg_Ubias=(fabs(Ubias_i-Ubias_j))/(match_limit_Ubias);
				leg_irradiation_change_dM=(fabs(irradiation_change_Ubias_i-irradiation_change_Ubias_j)/match_limit_irradiation_change_Ubias);
				leg_irradiation_change_Ubias=(fabs(irradiation_change_dM_i-irradiation_change_dM_j)/match_limit_irradiation_change_dM);
				sphere=sqrt(pow(leg_dM,2) + pow(leg_Ubias,2) + pow(leg_irradiation_change_dM,2) + pow(leg_irradiation_change_Ubias,2));
				cost[i][j]=sphere;
			}
			// if(i==j) cost[i][j]=100000000;
		}
	}

	for(size_t i = 0; i<apdvec_database.size(); i++)
	{
		for(size_t j = 0; j<apdvec_database.size(); j++)
		{
			cout << i << " " << j << " " << cost[i][j] <<endl;
		}
	}


	// Calculate amount of edges 
	double number=0;
	double n=N;
	double k=2;
	//number = tgammal(n + 1) / (tgammal(k + 1) * tgammal(n - k + 1));

	number=binom(n, k);
	cout << "\t Amount of edges: " << number <<endl;

	// convert edges for blossom
	int node_num;
	long int edge_num;
	node_num=N; 
	edge_num=(int)number;

	//int* edges = new int[2*edge_num];
	//double* weights = new double[edge_num];
	int* edges = new int[2*edge_num];
	double*	weights = new double[edge_num];

	cout << "\t\t " << node_num << " APDs and " << edge_num << " edges calculated" << endl;

	int e=0;
	for(size_t i = 0; i<apdvec_database.size(); i++)
	{
		for(size_t j = 0; j<apdvec_database.size(); j++)
		{	
			if(i!=j)
			{		
				// Assign edges among themselves
				edges[2*e] = (int)i;
				edges[2*e+1] = (int)j;
			
				// Use only triangular matrix without diagonals
				if(j>i){ weights[e] = (double)cost[i][j];}
				else{ if((int)+(int)j<node_num) weights[e] = (double)cost[i][j]; }
				e++;
				// { cout << "\t Break! Break! Break!" <<endl; break;}
			}
		}
	}
	return;
}


int main(int argc,char *argv[])
{    
	bool ignore_matched_apds=true;
	bool select_grids=false;
	bool EXTRACT_APD_VALUE=true;
	bool concern_irradiation=true;
	//bool simple=false;
	double fit_point=100.0;

	const char *INPUTFILE_DATABASE="APD-Database-Dump_-25C_radiated_algorithm7.txt";			// 10 APDs
	const char* INPUTFILE_DATABASE_IRRADIATED="APD-Database-Dump_-25C_radiated.txt";

	const char* INPUTFILE_IGNORE="input_SN_not_available.txt";
	const char* INPUTFILE_GRIDS="input_grids_available.txt";
	const char *OUTPUTFILE="edges.txt"; 

	vector<APD> apdvec_database;
	apdvec_database=database(INPUTFILE_DATABASE, EXTRACT_APD_VALUE, fit_point);

	// Take into account already matched APDs ?
	if(ignore_matched_apds==false)
	{
		vector<APD_ignore> apdvec_ignore;
		apdvec_ignore=apds_ignore(INPUTFILE_IGNORE);
		for(unsigned long int i=0;i<apdvec_ignore.size();i++)	
		{
			for(vector<APD>::iterator it = apdvec_database.begin(); it!=apdvec_database.end();)
			{
				if(it->getSN()==apdvec_ignore[i].getSN())
				{
					it=apdvec_database.erase(it);		
				} 
				else 
				{
					it++;
				}
			}
		}
		cout << apdvec_database.size() << " remaining APDs to match " << endl << endl;
	}

	// Concern APD behaviour after irradiation
	if(concern_irradiation)
	{
		apdvec_database=database_irradiated(INPUTFILE_DATABASE_IRRADIATED, EXTRACT_APD_VALUE, apdvec_database, fit_point);
	}

	// Select specific grids
	if(select_grids==true)
	{
		bool keep=false;
		vector<grids> gridvec;
		gridvec=grids_available(INPUTFILE_GRIDS);
		for(vector<APD>::iterator it = apdvec_database.begin(); it!=apdvec_database.end();)
		{ 
			for(unsigned long int i=0;i<gridvec.size();i++)	
			{		
				if(it->getgrid()==gridvec[i].getgrid())
				{	
					keep=true;
					break;
				} 		
			}
			if(keep==false) it=apdvec_database.erase(it); 
			else keep=false;
			it++;	
		} 
		cout << apdvec_database.size() << " APDs read out by considering " << gridvec.size() << " grids" << endl;
	}
	match(apdvec_database, OUTPUTFILE, EXTRACT_APD_VALUE);

	return 0; 
}

