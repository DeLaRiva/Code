#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "APD.h"
#include <Fit.h>


using namespace std;

string APD::MatchStateStrings[3] = {"UNDEFINED","NOT_MATCHED", "MATCHED"};
string APD::IrradiatedStateStrings[3] = {"UNKNOWN","NOT_IRRADIATED", "IRRADIATED"};

	APD::APD()
	{
		m_SN=0.0; 
		m_temperature=0.0; 
		m_rad=0.0; 
		m_grid=0.0; 
		m_grid_pos=0.0; 
		m_M=0.0; 
		m_Ubias=0.0; 
		m_Id=0.0; 
		m_M_dM=0.0;
		m_dM=0.0;
		m_Ubr=0.0;
		m_deviation_fits_APD=0.0;
		m_match_state=UNDEFINED;
		m_irradiated_state=UNKNOWN;
		m_irradiation_change_dM=0.0;
		m_irradiation_change_Ubias=0.0;
	}

	APD::~APD(){}	

	APD::APD(ifstream& input)	
//	APD::APD(ifstream& input, bool FIT_APDS, TFile* Outputfile)										// ifstream input to read from file
	{
		m_SN=0.0; 
		m_temperature=0.0; 
		m_rad=0.0; 
		m_grid=0.0; 
		m_grid_pos=0.0; 
		m_M=0.0; 
		m_Ubias=0.0; 
		m_Id=0.0; 
		m_M_dM=0.0;
		m_dM=0.0;
		m_Ubr=0.0;
		m_match_state=UNDEFINED;
		m_irradiated_state=UNKNOWN;

		m_fitted_raw_dM_APD=0.0;
		m_fitted_fit_dM_APD=0.0;
		m_corresponding_Ubias_raw_APD=0.0;
		m_corresponding_Ubias_fit_APD=0.0;
		m_deviation_fits_APD=0.0;

		m_irradiation_change_dM=0.0;
		m_irradiation_change_Ubias=0.0;

		string match_string_raw = "raw data:";
		string match_string_fit = "fit data:";
		string match_string_Ubr = "U_Br(fit):";
		string line_raw;
		string line_fit;
		string line_Ubr;

		while(!input.eof()) 
		{
			//getline(input, line_Ubr);
			{		
				//cout << "line: " << line_Ubr << endl;
				if(line_Ubr.compare(0,match_string_Ubr.length(),match_string_Ubr) == 0)
				{
					string dummy;
					//cout << "line: " << line_Ubr << endl;
					istringstream istr_Ubr(line_Ubr);
					istr_Ubr >> dummy >> m_Ubr;
					break;
				}
				else getline(input, line_Ubr);
			}
		}

		//raw data
		while(!input.eof()) 
		{			
			getline(input, line_raw);	
			
			if(line_raw.compare(0,match_string_raw.length(),match_string_raw) == 0)
			{		
				getline(input,line_raw);
				getline(input,line_raw);
				while(!line_raw.empty())
				{	
					istringstream istr_raw(line_raw);	
					istr_raw >> m_SN >> m_temperature >> m_rad >> m_grid >> m_grid_pos >> m_M >> m_Ubias >> m_Id >> m_M_dM >> m_dM;
					//cout << "line: " << line_raw << endl;
					//cout << "SN: " << m_SN << " Temp.: " << m_temperature << " rad: " << m_rad << " grid: " << m_grid << " grid_pos: " << m_grid_pos << " M: " << m_M << " Ubias: " << m_Ubias << " Id: " << m_Id << " M_dM: " << m_M_dM << " dM: " << m_dM << endl;
					if(m_SN!=0)
					{
						m_M_vec_raw.push_back(m_M);
						m_Ubias_vec_raw.push_back(m_Ubias);
						getline(input,line_raw);
					}
				}
				break;	
			}			
		}
		//cout << "SN: " << m_SN << " U_break: " << m_Ubr << endl;

		/* cout << endl << endl << "Size of M_vec_raw: " << M_vec_raw.size() << " SN: " << m_SN << endl;
		for(unsigned long int i=0;i<M_vec_raw.size();i++)
		{
			cout << "M_vec_raw: " << M_vec_raw[i] << " Ubias_vec_raw: " << Ubias_vec_raw[i] << endl;
		} */

		//fit data
		while(!input.eof()) 
		{			
			getline(input, line_fit);	
			
			if(line_fit.compare(0,match_string_fit.length(),match_string_fit) == 0)
			{		
				getline(input,line_fit);
				getline(input,line_fit);
				while(!line_fit.empty())
				{	
					istringstream istr_fit(line_fit);	
					istr_fit >> m_SN >> m_temperature >> m_rad >> m_grid >> m_grid_pos >> m_M >> m_Ubias >> m_Id >> m_dM;	
					if(m_SN!=0)
					{
						m_M_vec_fit.push_back(m_M);
						m_Ubias_vec_fit.push_back(m_Ubias);
						getline(input,line_fit);
					}
				}
				break;	
			}				
		}
	}

	void APD::fit_APD(TFile* Outputfile, double fit_point)
	{
		{
			FIT apd_fit(m_M_vec_raw, m_Ubias_vec_raw, m_M_vec_fit, m_Ubias_vec_fit, m_Ubr, m_SN, Outputfile, fit_point);

			m_fitted_raw_dM_APD=apd_fit.get_fitted_dM_raw();
			m_fitted_fit_dM_APD=apd_fit.get_fitted_dM_fit();
			m_corresponding_Ubias_raw_APD=apd_fit.get_corresponding_Ubias_raw();
			m_corresponding_Ubias_fit_APD=apd_fit.get_corresponding_Ubias_fit();
			m_deviation_fits_APD=apd_fit.get_deviation_fits();

			// cout << "m_fitted_raw_dM_APD: " << m_fitted_raw_dM_APD << endl;
		}
	}

	void APD::write(ostream& out) const
	{
		//out << "SN \t \t" << "temperature \t" << "rad \t" << "grid \t" << "grid_pos \t" << "M \t" << "\t Ubias \t" << "\t Id \t" << " dM "<<endl;
		out.fill('0'); 
		out << setw(10) << m_SN << "\t " << m_temperature <<  "\t \t" << m_rad <<  " \t" << m_grid << " \t" << m_grid_pos << "\t \t" << m_fit_point << " \t";
		out.setf(ios_base::fixed, ios_base::floatfield);
		out << setprecision(4) << m_corresponding_Ubias_raw_APD << " \t" << m_fitted_raw_dM_APD << " \t" << m_deviation_fits_APD;	
		//out << "M_vec: " << M_vec[0] << endl; 
	}


	ostream& operator<<(ostream& out, const APD& apd)
	{     
		apd.write(out);
		return out;
	}

	void APD::print() const
	{
		cout<<"SN	: "<<m_SN<<endl;
	}

	long int APD::getSN() const 
	{
		return m_SN;
	}
	void APD::setSN(long int a_SN) 
	{	
		m_SN=a_SN;	
	}

	double APD::gettemperature() const 
	{	
		return m_temperature;
	}
	void APD::settemperature(double a_temperature) 
	{
		m_temperature=a_temperature;
	}

	int APD::getrad() const 
	{
		return m_rad;
	}
	void APD::setrad(int a_rad)
	{
		m_rad=a_rad;
	}

	int APD::getgrid() const 
	{
		return m_grid;
	}
	void APD::setgrid(int a_grid)
	{
		m_grid=a_grid;
	}

	int APD::getgrid_pos() const 
	{
		return m_grid_pos;
	}
	void APD::setgrid_pos(int a_grid_pos)
	{
		m_grid_pos=a_grid_pos;
	}



	double APD::getM() const 
	{
		return m_M;
	}
	void APD::setM(double a_M)
	{
		m_M=a_M;
	}

	vector<double> APD::getM_vec_raw() const 
	{
		return m_M_vec_raw;
	}
	void APD::setM_vec_raw(vector<double> a_M_vec_raw)
	{
		m_M_vec_raw=a_M_vec_raw;
	}

	vector<double> APD::getM_vec_fit() const 
	{
		return m_M_vec_fit;
	}
	void APD::setM_vec_fit(vector<double> a_M_vec_fit)
	{
		m_M_vec_fit=a_M_vec_fit;
	}


	double APD::getUbias() const 
	{
		return m_Ubias;
	}
	void APD::setUbias(double a_Ubias)
	{
		m_Ubias=a_Ubias;
	}

	vector<double> APD::getUbias_vec_raw() const 
	{
		return m_Ubias_vec_raw;
	}
	void APD::setUbias_vec_raw(vector<double> a_Ubias_vec_raw)
	{
		m_Ubias_vec_raw=a_Ubias_vec_raw;
	}

	vector<double> APD::getUbias_vec_fit() const 
	{
		return m_Ubias_vec_fit;
	}
	void APD::setUbias_vec_fit(vector<double> a_Ubias_vec_fit)
	{
		m_Ubias_vec_fit=a_Ubias_vec_fit;
	}

	vector<double> APD::getdM_vec_raw() const 
	{
		return m_dM_vec_raw;
	}
	void APD::setdM_vec_raw(vector<double> a_dM_vec_raw)
	{
		m_dM_vec_raw=a_dM_vec_raw;
	}

	vector<double> APD::getdM_vec_fit() const 
	{
		return m_dM_vec_fit;
	}
	void APD::setdM_vec_fit(vector<double> a_dM_vec_fit)
	{
		m_dM_vec_fit=a_dM_vec_fit;
	}


	double APD::getUbr() const
	{
		return m_Ubr;
	}

	void APD::setUbr(double a_Ubr)
	{
		m_Ubr = a_Ubr;
	}

	double APD::getId() const
	{
		return m_Id;
	}
	void APD::setId(double a_Id)
	{
		m_Id=a_Id;
	}

	double APD::getM_dM() const
	{
		return m_M_dM;
	}

	void APD::setM_dM(double a_M_dM)
	{
		m_M_dM=a_M_dM;
	}

	double APD::getdM() const
	{
		return m_dM;
	}
	void APD::setdM(double a_dM)
	{
		m_dM=a_dM;
	}

	APD::MatchStateType APD::getMatchState() const
	{
		return m_match_state;
	}

	string APD::getMatchStateString() const 
	{
		return MatchStateStrings[(int)m_match_state];
	}
		
	void APD::setMatchState(int a_match_state)
	{
		m_match_state=static_cast<MatchStateType>(a_match_state);
	}


	double APD::get_fitted_dM_raw() const
	{
		return m_fitted_raw_dM_APD;
	}

	void APD::set_fitted_dM_raw(double a_fitted_raw_dM_APD)
	{
		m_fitted_raw_dM_APD = a_fitted_raw_dM_APD;
	}

	double APD::get_fitted_dM_fit() const
	{
		return m_fitted_fit_dM_APD;
	}

	void APD::set_fitted_dM_fit(double a_fitted_fit_dM_APD)
	{
		m_fitted_fit_dM_APD = a_fitted_fit_dM_APD;
	}

	double APD::get_corresponding_Ubias_raw() const
	{
		return m_corresponding_Ubias_raw_APD;
	}

	void APD::set_corresponding_Ubias_raw(double a_corresponding_Ubias_raw_APD)
	{
		m_corresponding_Ubias_raw_APD = a_corresponding_Ubias_raw_APD;
	}

	double APD::get_corresponding_Ubias_fit() const
	{
		return m_corresponding_Ubias_fit_APD;
	}

	void APD::set_corresponding_Ubias_fit(double a_corresponding_Ubias_fit_APD)
	{
		m_corresponding_Ubias_fit_APD = a_corresponding_Ubias_fit_APD;
	}

	double APD::get_deviation_fits() const
	{
		return m_deviation_fits_APD;
	}

	void APD::set_deviation_fits(double a_deviation_fits_APD)
	{
		m_deviation_fits_APD = a_deviation_fits_APD;
	}

	double APD::get_irradiation_change_dM() const
	{
		return m_irradiation_change_dM;
	}

	void APD::set_irradiation_change_dM(double a_irradiation_change_dM)
	{
		m_irradiation_change_dM = a_irradiation_change_dM;
	}

	double APD::get_irradiation_change_Ubias() const
	{
		return m_irradiation_change_Ubias;
	}

	void APD::set_irradiation_change_Ubias(double a_irradiation_change_Ubias)
	{
		m_irradiation_change_Ubias = a_irradiation_change_Ubias;
	}


	APD::IrradiatedStateType APD::getIrradiatedState() const
	{
		return m_irradiated_state;
	}

	string APD::getIrradiatedStateString() const 
	{
		return IrradiatedStateStrings[(int)m_irradiated_state];
	}
		
	void APD::setIrradiatedState(int a_irradiated_state)
	{
		m_irradiated_state=static_cast<IrradiatedStateType>(a_irradiated_state);
	}

	double APD::get_fit_point() const
	{
		return m_fit_point;

	}

	void APD::set_fit_point(double a_fit_point)
	{
		m_fit_point = a_fit_point;

	}

	/*
	APD::APD(ofstream& output) const									// ifstream input to read from file
	{
		out << endl;
		out << "SN \t \t" << "temperature \t" << "rad \t" << "grid \t" << "grid_pos \t" << "M \t" << "Ubias \t" << "\t Id \t" << "\t dM "<<endl;
		out << m_SN << "\t " << m_temperature <<  "\t \t" << m_rad <<  " \t" << m_grid << " \t" << m_grid_pos << "\t \t" << m_M << " \t" << m_Ubias << " \t" << m_Id << " \t" << m_dM;	
		out << endl;
		return out;
	} */
