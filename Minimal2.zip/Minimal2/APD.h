#ifndef APD_H
#define APD_H
#include <iostream>
using namespace std;

class TFile;

class APD
{
	public:
		friend ostream& operator<<(ostream& out, const APD& apd);					
		void write(ostream& out) const; 

		APD();	
		//APD(ifstream& input, bool FIT_APDS, TFile* Outputfile=0);
		APD(ifstream& input);									
		~APD();		
									
		// Matching
		enum MatchStateType{UNDEFINED=0,NOT_MATCHED=1, MATCHED=2};
		static string MatchStateStrings[3];
		MatchStateType getMatchState() const;
		string getMatchStateString() const;		
		void setMatchState(int a_match_state);

		// Irradiation
		enum IrradiatedStateType{UNKNOWN=0,NOT_IRRADIATED=1, IRRADIATED=2};
		static string IrradiatedStateStrings[3];
		IrradiatedStateType getIrradiatedState() const;
		string getIrradiatedStateString() const;		
		void setIrradiatedState(int a_irradiated_state);

		long int getSN() const;
		void setSN(long int a_SN);
		double gettemperature() const;
		void settemperature(double a_temperature);
		int getrad() const;
		void setrad(int a_rad);
		int getgrid() const;
		void setgrid(int a_grid);
		int getgrid_pos() const;
		void setgrid_pos(int a_grid_pos);

		double getM() const;
		void setM(double a_M);
		vector<double> getM_vec_raw() const;
		void setM_vec_raw(vector<double> a_M_vec_raw);
		vector<double> getM_vec_fit() const;
		void setM_vec_fit(vector<double> a_M_vec_fit);

		double getUbias() const;
		void setUbias(double a_Ubias);
		vector<double> getUbias_vec_raw() const;
		void setUbias_vec_raw(vector<double> a_Ubias_vec_raw);
		vector<double> getUbias_vec_fit() const;
		void setUbias_vec_fit(vector<double> a_Ubias_vec_fit);

		vector<double> getdM_vec_raw() const;
		void setdM_vec_raw(vector<double> a_dM_vec_raw);
		vector<double> getdM_vec_fit() const;
		void setdM_vec_fit(vector<double> a_dM_vec_fit);

		double getId() const;
		void setId(double a_Id);
		double getM_dM() const;
		void setM_dM(double a_M_dM);
		double getdM() const;
		void setdM(double a_dM);
		double getUbr() const;
		void setUbr(double a_Ubr);

		void print() const; 

		void fit_APD(TFile *Outputfile, double fit_point);	
		// void fit_APD(vector<double> m_M_vec_raw, vector<double> m_Ubias_vec_raw, vector<double> m_M_vec_fit, vector<double> m_Ubias_vec_fit, double m_Ubr, long int m_SN, Tfile *Outputfile);		

		double get_fitted_dM_raw() const;
		void set_fitted_dM_raw(double a_fitted_raw_dM_APD);
		double get_fitted_dM_fit() const;
		void set_fitted_dM_fit(double a_fitted_fit_dM_APD);

		double get_corresponding_Ubias_raw() const;
		void set_corresponding_Ubias_raw(double a_corresponding_Ubias_raw_APD);
		double get_corresponding_Ubias_fit() const;
		void set_corresponding_Ubias_fit(double a_corresponding_Ubias_fit_APD);
		double get_deviation_fits() const;
		void set_deviation_fits(double a_deviation_fits_APD);

		double get_irradiation_change_dM() const;
		void set_irradiation_change_dM(double a_irradiation_change_dM);

		double get_irradiation_change_Ubias() const;
		void set_irradiation_change_Ubias(double a_irradiation_change_Ubias);

		double get_fit_point() const;
		void set_fit_point(double a_fit_point);

		//APD(ofstream& output);
		//APD(int a_SN, double a_temperature, int a_rad, int a_grid, int a_grid_pos, double a_M, double a_Ubias, double a_Id, double a_dM); /* { m_SN=a_SN; m_UBias=a_UBias; }
		//friend istream& operator>>(istream& in, APD& apd);						

	private:
		long int m_SN;
		double m_temperature;
		int m_rad;
		int m_grid;
		int m_grid_pos;
		double m_M;
		double m_M_raw;
		double m_M_fit;
		double m_Ubias;
		double m_Id;
		double m_M_dM;
		double m_dM;
		double m_dm_raw;
		double m_dm_fit;

		// Match state
		MatchStateType m_match_state;

		// Vectors for fitting
		vector<double> m_M_vec_raw;
		vector<double> m_Ubias_vec_raw;
		vector<double> m_M_vec_fit;
		vector<double> m_Ubias_vec_fit;
		vector<double> m_dM_vec_raw;
		vector<double> m_dM_vec_fit;

		// variables for fitting
		double m_fitted_raw_dM_APD;
		double m_fitted_fit_dM_APD;
		double m_corresponding_Ubias_raw_APD;
		double m_corresponding_Ubias_fit_APD;
		double m_deviation_fits_APD;
		double m_Ubr;
		bool FIT_APDS;
		double m_fit_point;

		// irradiation parameters
		double m_irradiation_change_dM;
		double m_irradiation_change_Ubias;
		IrradiatedStateType m_irradiated_state;
};

#endif

