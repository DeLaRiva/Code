#ifndef GRIDS_H
#define GRIDS_H
#include <iostream>
using namespace std;

class grids
{
	public:
		friend ostream& operator<<(ostream& out, const grids& grids);					

		void write(ostream& out) const; 

		grids();	
		grids(ifstream& input_grids);									
		~grids();		

		int getgrid() const;
		void setgrid(int a_grid);				

	private:
		int m_grid;
};

#endif

