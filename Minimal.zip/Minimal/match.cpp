// No error by not reading/creating a file to generate the matrix

#include <fstream>
#include <iostream>
#include <string>
#include <limits>
#include <vector>
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>

using namespace std;
//using namespace R;   

constexpr inline size_t binom(size_t n, size_t k) noexcept
{
	return
	(k>n) ? 0:						// out of range
	(k==0 || k==n) ? 1:					// edge
	(k==1 || k==n-1) ? n:					// first
	(k+k < n) ?						// recursive:
	(binom(n-1,k-1)*n)/k:					// path to k=1   is faster
	(binom(n-1,k)*n)/(n-k);					// path to k=n-1 is faster
}


//--- Matching
void match()
{

	vector<vector<double> > cost (10, vector<double>(10,0));

	cost[0][0]=0;
	cost[0][1]=2.86391;
	cost[0][2]=26.8756;
	cost[0][3]=0.890283;
	cost[0][4]=16.2001;
	cost[0][5]=9.97992;
	cost[0][6]=13.8363;
	cost[0][7]=1.18177;
	cost[0][8]=6.87581;
	cost[0][9]=37.8272;


	cost[1][0]=2.86391;
	cost[1][1]=0;
	cost[1][2]=29.6306;
	cost[1][3]=2.01742;
	cost[1][4]=18.964;
	cost[1][5]=7.28407;
	cost[1][6]=16.6014;
	cost[1][7]=1.76795;
	cost[1][8]=4.21456;
	cost[1][9]=35.0976;

	cost[2][0]=26.8756;
	cost[2][1]=29.6306;
	cost[2][2]=0;
	cost[2][3]=27.7656;
	cost[2][4]=10.6758;
	cost[2][5]=36.8555;
	cost[2][6]=13.0394;
	cost[2][7]=28.0574;
	cost[2][8]=33.7514;
	cost[2][9]=64.7027;

	cost[3][0]=0.890283;
	cost[3][1]=2.01742;
	cost[3][2]=27.7656;
	cost[3][3]=0;
	cost[3][4]=17.0901;
	cost[3][5]=9.09006;
	cost[3][6]=14.7262;
	cost[3][7]=0.2936;
	cost[3][8]=5.98597;
	cost[3][9]=36.9374;

	cost[4][0]=16.2001;
	cost[4][1]=18.964;
	cost[4][2]=10.6758;
	cost[4][3]=17.0901;
	cost[4][4]=0;
	cost[4][5]=26.1799;
	cost[4][6]=2.36401;
	cost[4][7]=17.3818;
	cost[4][8]=23.0759;
	cost[4][9]=54.0269;

	cost[5][0]=9.97992;
	cost[5][1]=7.28407;
	cost[5][2]=36.8555;
	cost[5][3]=9.09006;
	cost[5][4]=26.1799;
	cost[5][5]=0;
	cost[5][6]=23.8161;
	cost[5][7]=8.79816;
	cost[5][8]=3.1041;
	cost[5][9]=27.8474;

	cost[6][0]=13.8363;
	cost[6][1]=16.6014;
	cost[6][2]=13.0394;
	cost[6][3]=14.7262;
	cost[6][4]=2.36401;
	cost[6][5]=23.8161;
	cost[6][6]=0;
	cost[6][7]=15.018;
	cost[6][8]=20.712;
	cost[6][9]=51.6632;

	cost[7][0]=1.18177;
	cost[7][1]=1.76795;
	cost[7][2]=28.0574;
	cost[7][3]=0.2936;
	cost[7][4]=17.3818;
	cost[7][5]=8.79816;
	cost[7][6]=15.018;
	cost[7][7]=0;
	cost[7][8]=5.69406;
	cost[7][9]=36.6454;

	cost[8][0]=6.87581;
	cost[8][1]=4.21456;
	cost[8][2]=33.7514;
	cost[8][3]=5.98597;
	cost[8][4]=23.0759;
	cost[8][5]=3.1041;
	cost[8][6]=20.712;
	cost[8][7]=5.69406;
	cost[8][8]=0;
	cost[8][9]=30.9515;

	cost[9][0]=37.8272;
	cost[9][1]=35.0976;
	cost[9][2]=64.7027;
	cost[9][3]=36.9374;
	cost[9][4]=54.0269;
	cost[9][5]=27.8474;
	cost[9][6]=51.6632;
	cost[9][7]=36.6454;
	cost[9][8]=30.9515;
	cost[9][9]=0;


	for(size_t i = 0; i<cost.size(); i++)
	{
		for(size_t j = 0; j<cost.size(); j++)
		{
			cout << i << " " << j << " " << cost[i][j] <<endl;
		}
	}


	// Calculate amount of edges 
	double number=0;
	double n=10;
	double k=2;
	//number = tgammal(n + 1) / (tgammal(k + 1) * tgammal(n - k + 1));

	number=binom(n, k);
	cout << "\t Amount of edges: " << number <<endl;

	// convert edges for blossom
	int node_num;
	long int edge_num;
	node_num=10; 
	edge_num=(int)number;

	//int* edges = new int[2*edge_num];
	//double* weights = new double[edge_num];
	int* edges = new int[2*edge_num];
	double*	weights = new double[edge_num];

	cout << "\t\t " << node_num << " APDs and " << edge_num << " edges calculated" << endl;

	int e=0;
	for(size_t i = 0; i<cost.size(); i++)
	{
		for(size_t j = 0; j<cost.size(); j++)
		{	
			if(i!=j)
			{		
				// Assign edges among themselves
				edges[2*e] = (int)i;
				edges[2*e+1] = (int)j;
			
				// Use only triangular matrix without diagonals
				if(j>i){ weights[e] = (double)cost[i][j];}
				else{ if((int)+(int)j<node_num) weights[e] = (double)cost[i][j]; }
				e++;
			}
		}
	}
	return;
}


int main(int argc,char *argv[])
{    
	match();
	return 0; 
}

